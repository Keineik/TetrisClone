#ifndef GAME_H
#define GAME_H
#include <SFML/Graphics.hpp>
#include "Board.h"

class Game{
    private:
        Board board;
        int screenH, screenW;
        sf::Window window;
        static int blockSize;
    public:
        

};

#endif

